possible improvements
- hook management for optimization
- containerize bigger chunks of code to smaller components in converter

shortcuts 
- purely useState, useEffect