roadmap for future
- implement d3.js, chart.js or any other charting library to show change of dynamic FxRate from Api pull
- implement a dropdown for different currencies
- two-way input to convert either currency1 or currency2 without having to swap with a button
- metrics for yields for each currency -> for potential hedges with calculations with current app