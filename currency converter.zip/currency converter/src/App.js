import './App.css';
import Converter from "./components/Converter"

function App() {
  return (
    <div id = "app">
      <Converter />
    </div>
  );
}

export default App;
